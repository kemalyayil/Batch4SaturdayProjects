package project7.testClasses;

public class yourTest {

    /*

        Create a Test for method in the Users randomNumberCreader

        Check all possible options

     */

    /*
        Create a Test for method in the Users checkAge

        Check all possible options

     */


}
