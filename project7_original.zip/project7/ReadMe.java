package project7;

public class ReadMe {

    /*
        In this project you will create
        bank accounts
        make a transfer between the accounts
        add partner to your account

        First start with Account class > AddRelative class > Users class

        All other information in the classes.

        Create your own test in the your test class. Test all the possible scenarios.

     */
}
