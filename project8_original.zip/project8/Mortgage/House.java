package project8.Mortgage;

public class House {
  /*
     This class has the following fields (instance/object variables)
     String ownerName
     String condition
     String houseType
     int roomCount
     int downPayment
     int numberOfMonths
     StatesTax statesTax;
  */


    /*
    Create the constructor helping initialization of the object variables.
    (That is to say, the constructor takes all the object variables as parameter.)
     */


    /*
    Make all the object variables read-only. (No setter method, only getter methods are defined.)
     */

}

